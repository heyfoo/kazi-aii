import type { NextConfig } from "next";
import path from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = path.dirname(fileURLToPath(import.meta.url));

const nextConfig: NextConfig = {
  serverExternalPackages: ["playwright"],
  allowedDevOrigins: ["10.0.0.198"],
  turbopack: {
    root: projectRoot,
  },
};

export default nextConfig;
