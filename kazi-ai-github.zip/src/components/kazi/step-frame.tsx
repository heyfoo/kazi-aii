"use client";

import Link from "next/link";
import { cn } from "@/lib/utils";

const STEPS = [
  { key: "job", label: "1. Job", hint: "Benchmark" },
  { key: "resume", label: "2. Resume", hint: "Rewrite" },
  { key: "apply", label: "3. Apply", hint: "Fill the form" },
] as const;

export type FlowStep = (typeof STEPS)[number]["key"];

export function StepFrame({ id, step, children }: { id?: string; step: FlowStep; children: React.ReactNode }) {
  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-5 px-4 py-6 sm:px-6">
      <div className="flex items-center justify-between gap-3">
        <Link href="/job" className="flex items-center gap-2">
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-sm font-bold text-primary-foreground">K</span>
          <span className="font-semibold tracking-tight">Kazi</span>
        </Link>
      </div>
      <nav className="grid grid-cols-3 gap-2" aria-label="Application steps">
        {STEPS.map((item) => {
          const href = item.key === "job" ? (id ? `/job/${id}` : "/job") : id ? `/${item.key}/${id}` : "";
          const current = item.key === step;
          const className = cn(
            "rounded-lg border px-3 py-2 text-left text-sm",
            current ? "border-primary bg-primary/10 font-medium" : "border-border text-muted-foreground hover:bg-muted",
            !href && "pointer-events-none opacity-50",
          );
          const body = (
            <>
              <span className="block">{item.label}</span>
              <span className="block text-xs font-normal text-muted-foreground">{item.hint}</span>
            </>
          );
          return href ? (
            <Link key={item.key} href={href} className={className} aria-current={current ? "step" : undefined}>
              {body}
            </Link>
          ) : (
            <span key={item.key} className={className}>
              {body}
            </span>
          );
        })}
      </nav>
      {children}
    </div>
  );
}
