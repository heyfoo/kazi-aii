import { cloneElement, Fragment, isValidElement, type ReactNode } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { cn } from "@/lib/utils";

const PROOF = "[NEEDS PROOF]";

export function ProofText({ text }: { text: string }) {
  if (!text.includes(PROOF)) return text;
  const parts = text.split(PROOF);
  return parts.flatMap((part, i) => (i === 0 ? [part] : [<mark key={i} className="proof-mark">NEEDS PROOF</mark>, part]));
}

function withProof(node: ReactNode): ReactNode {
  if (typeof node === "string") return <ProofText text={node} />;
  if (typeof node === "number" || node == null || typeof node === "boolean") return node;
  if (Array.isArray(node)) return node.map((child, i) => <Fragment key={i}>{withProof(child)}</Fragment>);
  if (isValidElement<{ children?: ReactNode }>(node)) {
    return cloneElement(node, undefined, withProof(node.props.children));
  }
  return node;
}

const proofTags = ["h1", "h2", "h3", "p", "li", "strong", "em"] as const;

export function Markdown({ children, className }: { children: string; className?: string }) {
  return (
    <div className={cn("kazi-md", className)}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={Object.fromEntries(
          proofTags.map((tag) => [
            tag,
            ({ children: inner }: { children?: ReactNode }) => {
              const El = tag;
              return <El>{withProof(inner)}</El>;
            },
          ]),
        )}
      >
        {children}
      </ReactMarkdown>
    </div>
  );
}
