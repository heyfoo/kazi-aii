"use client";

import Link from "next/link";
import { useState } from "react";
import { ExternalLink, RotateCcw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/kazi/client";
import { hostOf, STATUS_LABEL, STATUS_PROGRESS } from "@/lib/kazi/labels";
import type { Job } from "@/lib/kazi/types";
import { StatusBadge } from "./status-badge";
import { StepFrame } from "./step-frame";
import { useJob } from "./use-job";

export function JobBenchmark({ id }: { id: string }) {
  const { job, notFound, error, setError, load, active } = useJob(id);
  const [jdDraft, setJdDraft] = useState("");
  const [busy, setBusy] = useState<string | null>(null);

  async function run(key: string, fn: () => Promise<unknown>) {
    setBusy(key);
    setError(null);
    try {
      await fn();
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  }

  if (notFound) return <StepFrame id={id} step="job"><p className="text-sm text-muted-foreground">This job no longer exists.</p></StepFrame>;
  if (!job) return <StepFrame id={id} step="job"><div className="h-40 animate-pulse rounded-xl bg-muted" /></StepFrame>;

  const title = job.analysis?.title || hostOf(job.url);
  const ready = Boolean(job.analysis) && !active;

  return (
    <StepFrame id={id} step="job">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
          <p className="text-sm text-muted-foreground">
            {job.analysis?.company && <span>{job.analysis.company} · </span>}
            <a href={job.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 hover:underline">
              {hostOf(job.url)} <ExternalLink className="size-3" />
            </a>
          </p>
        </div>
        <StatusBadge status={job.status} />
      </header>

      {active && (
        <div className="grid gap-1">
          <Progress value={STATUS_PROGRESS[job.status]} />
          <p className="text-xs text-muted-foreground">{job.log.at(-1)?.slice(9) ?? STATUS_LABEL[job.status]}</p>
        </div>
      )}
      {error && <ErrorNote message={error} />}

      {job.status === "needs_jd" && (
        <Card>
          <CardHeader>
            <CardTitle>Paste the job description</CardTitle>
            <CardDescription>{job.error}</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3">
            <Textarea value={jdDraft} onChange={(e) => setJdDraft(e.target.value)} className="min-h-64 text-sm" placeholder="Copy the full posting and paste it here…" />
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => run("jd", () => api.patchJob(id, { jdText: jdDraft }))} disabled={jdDraft.trim().length < 100 || busy === "jd"}>
                Analyze this description
              </Button>
              <Button variant="outline" onClick={() => run("retry", () => api.runJob(id, "analyze"))}>
                <RotateCcw data-icon="inline-start" /> Retry fetch
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {job.status === "error" && (
        <Card>
          <CardHeader>
            <CardTitle>Analysis failed</CardTitle>
            <CardDescription>{job.error}</CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" onClick={() => run("retry", () => api.runJob(id, "analyze"))}>
              <RotateCcw data-icon="inline-start" /> Try again
            </Button>
          </CardContent>
        </Card>
      )}

      {job.analysis && <Benchmark job={job} />}

      {ready && (
        <div className="flex justify-end">
          <Button nativeButton={false} render={<Link href={`/resume/${id}`} />}>
            Rewrite my resume toward this benchmark
          </Button>
        </div>
      )}
    </StepFrame>
  );
}

function Benchmark({ job }: { job: Job }) {
  const a = job.analysis!;
  return (
    <div className="grid gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Ideal applicant</CardTitle>
          <CardDescription>A composite of public career patterns for this role. Not a real person, and not your resume.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 text-sm">
          <p>{a.exampleCandidate || "The model did not describe an example candidate."}</p>
          <div className="flex flex-wrap gap-1">
            {a.seniority && <Badge variant="outline">{a.seniority}</Badge>}
            {a.location && <Badge variant="outline">{a.location}</Badge>}
          </div>
          {a.summary && <p className="text-muted-foreground">{a.summary}</p>}
        </CardContent>
      </Card>
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>What the role selects for</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3">
            <List title="Signals" items={a.signals} />
            <List title="Strong evidence" items={a.strongEvidence} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Rubric</CardTitle>
          </CardHeader>
          <CardContent>
            {a.rubric.length === 0 ? (
              <p className="text-sm text-muted-foreground">No rubric yet.</p>
            ) : (
              <ul className="grid gap-2 text-sm">
                {a.rubric.map((row) => (
                  <li key={row.criterion} className="flex items-start justify-between gap-3">
                    <span>{row.criterion}</span>
                    <span className="tabular-nums text-muted-foreground">{Math.round(row.weight * 100)}%</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function List({ title, items }: { title: string; items: string[] }) {
  if (!items.length) return null;
  return (
    <div>
      <p className="mb-1 text-xs font-medium text-muted-foreground">{title}</p>
      <ul className="list-disc space-y-1 pl-5 text-sm">
        {items.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

function ErrorNote({ message }: { message: string }) {
  return (
    <div role="alert" className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
      {message}
    </div>
  );
}
