"use client";

import Link from "next/link";
import { useState } from "react";
import { Check, ExternalLink, TextCursorInput } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { api, downloadText, slug } from "@/lib/kazi/client";
import { hostOf } from "@/lib/kazi/labels";
import { Markdown, ProofText } from "./markdown";
import { StatusBadge } from "./status-badge";
import { StepFrame } from "./step-frame";
import { useJob } from "./use-job";

function readableFillError(line: string): string {
  const text = line.replace(/^\d{2}:\d{2}:\d{2}\s/, "").split("\n")[0];
  if (text.includes("Executable doesn't exist")) {
    return "The form filler's browser is not installed. In the project folder, run: npx playwright install chromium";
  }
  return text;
}

export function ApplyStep({ id }: { id: string }) {
  const { job, notFound, error, setError, load } = useJob(id);
  const [busy, setBusy] = useState<string | null>(null);
  const [fillNote, setFillNote] = useState<string | null>(null);

  async function run(key: string, fn: () => Promise<unknown>) {
    setBusy(key);
    setError(null);
    try {
      await fn();
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  }

  if (notFound) return <StepFrame id={id} step="apply"><p className="text-sm text-muted-foreground">This job no longer exists.</p></StepFrame>;
  if (!job) return <StepFrame id={id} step="apply"><div className="h-40 animate-pulse rounded-xl bg-muted" /></StepFrame>;

  const title = job.analysis?.title || hostOf(job.url);
  const fileBase = slug(`${job.analysis?.company ?? hostOf(job.url)}-${title}`);
  const hasDocs = Boolean(job.tailoredResume || job.coverLetter);

  return (
    <StepFrame id={id} step="apply">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Apply</h1>
          <p className="text-sm text-muted-foreground">
            {title}
            {job.analysis?.company ? ` at ${job.analysis.company}` : ""}. Kazi types the approved documents and stops before Submit.
          </p>
        </div>
        <StatusBadge status={job.status} />
      </header>
      {error && (
        <div role="alert" className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {error}
        </div>
      )}
      {fillNote && <p className="text-sm text-muted-foreground">{fillNote}</p>}

      {!hasDocs && (
        <Card>
          <CardHeader>
            <CardTitle>Nothing to submit yet</CardTitle>
            <CardDescription>Rewrite the resume for this benchmark first.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button nativeButton={false} variant="outline" render={<Link href={`/resume/${id}`} />}>
              Go to resume
            </Button>
          </CardContent>
        </Card>
      )}

      {job.tailoredResume && (
        <Card>
          <CardHeader>
            <CardTitle>Resume that will be used</CardTitle>
          </CardHeader>
          <CardContent>
            <Markdown>{job.tailoredResume}</Markdown>
          </CardContent>
        </Card>
      )}
      {job.coverLetter && (
        <Card>
          <CardHeader>
            <CardTitle>Cover letter that will be used</CardTitle>
          </CardHeader>
          <CardContent className="whitespace-pre-wrap text-sm">
            <ProofText text={job.coverLetter} />
          </CardContent>
        </Card>
      )}

      {hasDocs && (
        <div className="flex flex-wrap gap-2">
          {job.status === "ready_for_review" && (
            <>
              <Button variant="outline" onClick={() => run("reject", () => api.patchJob(id, { action: "reject" }))} disabled={busy !== null}>
                Reject
              </Button>
              <Button onClick={() => run("approve", () => api.patchJob(id, { action: "approve" }))} disabled={busy !== null}>
                <Check data-icon="inline-start" /> Approve
              </Button>
            </>
          )}
          {job.status === "approved" && (
            <>
              <Button
                variant="outline"
                disabled={busy !== null}
                onClick={() =>
                  run("fill", async () => {
                    setFillNote(null);
                    const before = job.log.length;
                    const result = await api.fillForm(id);
                    setFillNote(`A ${result.board} window is opening. Review the fields, then click Submit yourself.`);
                    for (let attempt = 0; attempt < 12; attempt++) {
                      await new Promise((resolve) => setTimeout(resolve, 1000));
                      const { job: fresh } = await api.job(id);
                      const failed = fresh.log.slice(before).find((entry) => entry.includes("Form fill failed"));
                      if (!failed) continue;
                      setFillNote(null);
                      throw new Error(readableFillError(failed));
                    }
                  })
                }
              >
                <TextCursorInput data-icon="inline-start" /> Fill the form
              </Button>
              <Button
                onClick={() => {
                  window.open(job.url, "_blank", "noopener");
                }}
              >
                <ExternalLink data-icon="inline-start" /> Open posting
              </Button>
              <Button variant="outline" onClick={() => downloadText(`${fileBase}-resume.md`, job.tailoredResume ?? "")}>
                Download resume
              </Button>
              <Button onClick={() => run("applied", () => api.patchJob(id, { action: "applied" }))} disabled={busy !== null}>
                <Check data-icon="inline-start" /> I submitted it
              </Button>
            </>
          )}
          {(job.status === "rejected" || job.status === "applied") && (
            <Button variant="outline" onClick={() => run("reopen", () => api.patchJob(id, { action: "reopen" }))} disabled={busy !== null}>
              Reopen
            </Button>
          )}
          {job.status === "applied" && <p className="self-center text-sm text-muted-foreground">Recorded as applied.</p>}
        </div>
      )}
    </StepFrame>
  );
}
