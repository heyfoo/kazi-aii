"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { Upload } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { api } from "@/lib/kazi/client";
import { hostOf, RECOMMENDATION_LABEL, STATUS_LABEL, STATUS_PROGRESS } from "@/lib/kazi/labels";
import type { Resume } from "@/lib/kazi/types";
import { Markdown, ProofText } from "./markdown";
import { StatusBadge } from "./status-badge";
import { StepFrame } from "./step-frame";
import { useJob } from "./use-job";

export function ResumeStep({ id }: { id: string }) {
  const { job, notFound, error, setError, load, active } = useJob(id);
  const [resume, setResume] = useState<Resume | null>(null);
  const [draft, setDraft] = useState("");
  const [editing, setEditing] = useState(false);
  const [resumeDraft, setResumeDraft] = useState("");
  const [coverDraft, setCoverDraft] = useState("");
  const [editingDocs, setEditingDocs] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const seenDocs = useRef<{ resume?: string; cover?: string }>({});

  useEffect(() => {
    api
      .resume()
      .then(({ resume }) => {
        setResume(resume);
        setEditing(!resume);
      })
      .catch((err) => setError((err as Error).message));
  }, [setError]);

  useEffect(() => {
    if (!job) return;
    if (seenDocs.current.resume !== job.tailoredResume) {
      seenDocs.current.resume = job.tailoredResume;
      setResumeDraft(job.tailoredResume ?? "");
    }
    if (seenDocs.current.cover !== job.coverLetter) {
      seenDocs.current.cover = job.coverLetter;
      setCoverDraft(job.coverLetter ?? "");
    }
  }, [job]);

  async function run(key: string, fn: () => Promise<unknown>) {
    setBusy(key);
    setError(null);
    try {
      await fn();
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  }

  async function saveResume() {
    await run("resume", async () => {
      const { resume } = await api.saveResumeText(draft);
      setResume(resume);
      setEditing(false);
    });
  }

  async function upload(file: File) {
    await run("resume", async () => {
      const { resume } = await api.saveResumeFile(file);
      setResume(resume);
      setEditing(false);
    });
  }

  if (notFound) return <StepFrame id={id} step="resume"><p className="text-sm text-muted-foreground">This job no longer exists.</p></StepFrame>;
  if (!job) return <StepFrame id={id} step="resume"><div className="h-40 animate-pulse rounded-xl bg-muted" /></StepFrame>;

  const benchmarkReady = Boolean(job.analysis);
  const dirty = resumeDraft !== (job.tailoredResume ?? "") || coverDraft !== (job.coverLetter ?? "");

  return (
    <StepFrame id={id} step="resume">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Resume</h1>
          <p className="text-sm text-muted-foreground">
            Rewrite toward {job.analysis?.title || hostOf(job.url)}
            {job.analysis?.company ? ` at ${job.analysis.company}` : ""}. Amber marks are claims that are not on your original resume.
          </p>
        </div>
        <StatusBadge status={job.status} />
      </header>

      {active && (
        <div className="grid gap-1">
          <Progress value={STATUS_PROGRESS[job.status]} />
          <p className="text-xs text-muted-foreground">{job.log.at(-1)?.slice(9) ?? STATUS_LABEL[job.status]}</p>
        </div>
      )}
      {error && <ErrorNote message={error} />}

      {!benchmarkReady && !active && (
        <Card>
          <CardHeader>
            <CardTitle>The benchmark is not ready</CardTitle>
            <CardDescription>Analyze the posting before rewriting.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button nativeButton={false} variant="outline" render={<Link href={`/job/${id}`} />}>
              Back to the job
            </Button>
          </CardContent>
        </Card>
      )}

      {job.analysis?.exampleCandidate && (
        <Card>
          <CardHeader>
            <CardTitle>Benchmark to close</CardTitle>
            <CardDescription>Composite of public career patterns for this role. Not a real person.</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm">{job.analysis.exampleCandidate}</p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Your resume</CardTitle>
          <CardDescription>Stored on this machine. A new upload replaces it.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3">
          {resume && !editing ? (
            <div className="grid gap-1 text-sm">
              <div className="flex items-center justify-between">
                <span className="font-medium">{resume.profile?.name || resume.fileName || "Resume on file"}</span>
                <span className="text-xs text-muted-foreground">{resume.rawText.length.toLocaleString()} chars</span>
              </div>
              <pre className="max-h-32 overflow-auto rounded-md bg-muted p-3 text-xs whitespace-pre-wrap">{resume.rawText.slice(0, 600)}</pre>
            </div>
          ) : (
            <Textarea value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Paste your resume…" className="min-h-48 font-mono text-xs" />
          )}
        </CardContent>
        <CardFooter className="flex flex-wrap gap-2">
          {resume && !editing ? (
            <Button variant="outline" size="sm" onClick={() => { setDraft(resume.rawText); setEditing(true); }}>
              Edit text
            </Button>
          ) : (
            <>
              <Button size="sm" onClick={saveResume} disabled={busy === "resume" || draft.trim().length < 200}>
                Save resume
              </Button>
              {resume && (
                <Button variant="ghost" size="sm" onClick={() => setEditing(false)}>
                  Cancel
                </Button>
              )}
            </>
          )}
          <label className={cn(buttonVariants({ variant: "outline", size: "sm" }), "cursor-pointer", busy === "resume" && "pointer-events-none opacity-50")}>
            <Upload data-icon="inline-start" /> Upload PDF
            <input
              type="file"
              accept=".pdf,.txt,.md,text/plain,application/pdf"
              className="sr-only"
              disabled={busy === "resume"}
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) void upload(file);
                e.target.value = "";
              }}
            />
          </label>
          <Button className="ml-auto" onClick={() => run("tailor", () => api.runJob(id, "tailor"))} disabled={!resume || !benchmarkReady || active || busy !== null}>
            Rewrite toward this benchmark
          </Button>
        </CardFooter>
      </Card>

      {job.fit && (
        <p className="text-sm text-muted-foreground">
          Fit: <Badge variant={job.fit.recommendation === "skip" ? "destructive" : "secondary"}>{RECOMMENDATION_LABEL[job.fit.recommendation]}</Badge>
          {job.fit.missingSkills.length > 0 && <span> Missing: {job.fit.missingSkills.slice(0, 6).join(", ")}</span>}
        </p>
      )}

      {job.tailoredResume && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <CardTitle>Tailored resume</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => setEditingDocs((v) => !v)} disabled={active}>
              {editingDocs ? "Preview" : "Edit"}
            </Button>
          </CardHeader>
          <CardContent>
            {editingDocs ? (
              <Textarea value={resumeDraft} onChange={(e) => setResumeDraft(e.target.value)} className="min-h-96 font-mono text-xs" />
            ) : (
              <Markdown>{resumeDraft}</Markdown>
            )}
          </CardContent>
        </Card>
      )}

      {job.coverLetter && (
        <Card>
          <CardHeader>
            <CardTitle>Cover letter</CardTitle>
            <CardDescription>
              {job.verification ? `Fabrication risk ${Math.round(job.verification.fabricationRisk * 100)}%.` : "Checked against your resume."} Sentences with an amber mark are hypothetical.
            </CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3">
            {editingDocs ? (
              <Textarea value={coverDraft} onChange={(e) => setCoverDraft(e.target.value)} className="min-h-64 text-sm" />
            ) : (
              <div className="kazi-md whitespace-pre-wrap text-sm">
                <ProofText text={coverDraft} />
              </div>
            )}
            {job.verification && job.verification.unsupportedClaims.length > 0 && (
              <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
                {job.verification.unsupportedClaims.map((claim) => (
                  <li key={claim}>{claim}</li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      )}

      {job.changeNotes.length > 0 && (
        <div>
          <p className="mb-1 text-xs font-medium text-muted-foreground">What changed</p>
          <ul className="list-disc space-y-1 pl-5 text-sm">
            {job.changeNotes.map((note) => (
              <li key={note}>
                <ProofText text={note} />
              </li>
            ))}
          </ul>
        </div>
      )}

      {(dirty || job.tailoredResume) && (
        <div className="flex flex-wrap justify-end gap-2">
          {dirty && (
            <Button variant="outline" onClick={() => run("save", () => api.patchJob(id, { tailoredResume: resumeDraft, coverLetter: coverDraft }))} disabled={busy === "save"}>
              Save edits
            </Button>
          )}
          {job.tailoredResume && (
            <Button nativeButton={false} render={<Link href={`/apply/${id}`} />}>
              Continue to apply
            </Button>
          )}
        </div>
      )}
    </StepFrame>
  );
}

function ErrorNote({ message }: { message: string }) {
  return (
    <div role="alert" className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
      {message}
    </div>
  );
}
