"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/kazi/client";
import { ACTIVE_STATUSES, type Job } from "@/lib/kazi/types";

export function useJob(id: string) {
  const [job, setJob] = useState<Job | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const { job } = await api.job(id);
      setJob(job);
    } catch (err) {
      if ((err as Error).message.includes("not found")) setNotFound(true);
      else setError((err as Error).message);
    }
  }, [id]);

  const active = job ? ACTIVE_STATUSES.includes(job.status) || job.status === "queued" : false;
  useEffect(() => {
    const tick = () => void load();
    const first = setTimeout(tick, 0);
    const interval = active ? setInterval(tick, 1200) : undefined;
    return () => {
      clearTimeout(first);
      if (interval) clearInterval(interval);
    };
  }, [active, load]);

  return { job, notFound, error, setError, load, active };
}
