"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { ArrowRight, Link2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/kazi/client";
import { hostOf } from "@/lib/kazi/labels";
import { ACTIVE_STATUSES, type Job } from "@/lib/kazi/types";
import { StatusBadge } from "./status-badge";
import { StepFrame } from "./step-frame";

export function JobHome() {
  const router = useRouter();
  const [links, setLinks] = useState("");
  const [jobs, setJobs] = useState<Job[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const { jobs } = await api.jobs();
      setJobs(jobs);
    } catch (err) {
      setError((err as Error).message);
    }
  }, []);

  const anyActive = jobs?.some((job) => ACTIVE_STATUSES.includes(job.status) || job.status === "queued") ?? false;
  useEffect(() => {
    const tick = () => void refresh();
    const first = setTimeout(tick, 0);
    const interval = anyActive ? setInterval(tick, 1500) : undefined;
    return () => {
      clearTimeout(first);
      if (interval) clearInterval(interval);
    };
  }, [anyActive, refresh]);

  async function analyze() {
    setBusy(true);
    setError(null);
    try {
      const { jobs: created } = await api.addJobs(links);
      setLinks("");
      if (created[0]) router.push(`/job/${created[0].id}`);
      else await refresh();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <StepFrame step="job">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Job</h1>
        <p className="text-sm text-muted-foreground">Paste a posting link. Kazi reads it and builds an ideal-applicant benchmark before it looks at your resume.</p>
      </header>
      {error && <ErrorNote message={error} />}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Link2 className="size-4" /> Job link
          </CardTitle>
          <CardDescription>One URL per line. Sites that block bots will ask you to paste the description on the next page.</CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            value={links}
            onChange={(e) => setLinks(e.target.value)}
            placeholder="https://boards.greenhouse.io/acme/jobs/123"
            className="min-h-28 font-mono text-xs"
          />
        </CardContent>
        <CardFooter className="justify-end">
          <Button onClick={analyze} disabled={busy || !links.trim()}>
            Analyze role
          </Button>
        </CardFooter>
      </Card>
      <section className="grid gap-2">
        <h2 className="text-sm font-medium text-muted-foreground">Recent postings</h2>
        {jobs === null ? (
          <div className="h-16 animate-pulse rounded-xl bg-muted" />
        ) : jobs.length === 0 ? (
          <p className="text-sm text-muted-foreground">No jobs yet.</p>
        ) : (
          <ul className="grid gap-2">
            {jobs.map((job) => (
              <li key={job.id}>
                <Link href={`/job/${job.id}`} className="flex items-center justify-between gap-3 rounded-xl border px-4 py-3 hover:bg-muted">
                  <span className="min-w-0">
                    <span className="block truncate font-medium">{job.analysis?.title || hostOf(job.url)}</span>
                    <span className="block truncate text-xs text-muted-foreground">{job.analysis?.company || hostOf(job.url)}</span>
                  </span>
                  <span className="flex items-center gap-2">
                    <StatusBadge status={job.status} />
                    <ArrowRight className="size-4 text-muted-foreground" />
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </StepFrame>
  );
}

function ErrorNote({ message }: { message: string }) {
  return (
    <div role="alert" className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
      {message}
    </div>
  );
}
