import { ApplyStep } from "@/components/kazi/apply-step";

export default async function ApplyPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <ApplyStep id={id} />;
}
