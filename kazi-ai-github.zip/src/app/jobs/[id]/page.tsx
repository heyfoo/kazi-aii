import { redirect } from "next/navigation";

export default async function LegacyJobPage(props: PageProps<"/jobs/[id]">) {
  const { id } = await props.params;
  redirect(`/job/${id}`);
}
