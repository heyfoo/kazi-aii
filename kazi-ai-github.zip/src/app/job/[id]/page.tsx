import { JobBenchmark } from "@/components/kazi/job-benchmark";

export default async function JobBenchmarkPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <JobBenchmark id={id} />;
}
