import { JobHome } from "@/components/kazi/job-home";

export default function JobIndexPage() {
  return <JobHome />;
}
