import { ResumeStep } from "@/components/kazi/resume-step";

export default async function ResumePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <ResumeStep id={id} />;
}
