const STOPWORDS = new Set(
  `a an and are as at be by for from has have in is it its of on or that the to was were will with you your we our this these those their they them he she his her not no yes can may must should would could about across after against all also any because been before being between both but each few more most other over own same so some such than then there through under until up very what when where which while who whom why how into out off only per via etc`.split(
    /\s+/,
  ),
);

export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9+#.\s/-]/g, " ")
    .split(/\s+/)
    .map((t) => t.replace(/^[.\-/]+|[.\-/]+$/g, ""))
    .filter((t) => t.length > 1 && !STOPWORDS.has(t) && !/^\d+$/.test(t));
}

export function termSet(text: string): Set<string> {
  return new Set(tokenize(text));
}

/** Fraction of `needles` terms that appear in `haystack`. */
export function coverage(needles: string[], haystack: string): { matched: string[]; missing: string[]; ratio: number } {
  const matched: string[] = [];
  const missing: string[] = [];
  for (const n of needles) (requirementSupported(n, haystack) ? matched : missing).push(n);
  return { matched, missing, ratio: needles.length ? matched.length / needles.length : 0 };
}

const QUALIFIER = new Set(
  "proficiency skill skills strong background experience hands hands-on coding fluency knowledge ability framework frameworks technique techniques versatile practical empirical problem problems".split(/\s+/),
);

const PROGRAMMING = new Set("python javascript typescript java kotlin swift go golang rust ruby php scala sql bash c c++ c# r".split(/\s+/));

const ALIAS: Record<string, string[]> = {
  cs: ["computer science", "cs"],
  math: ["math", "mathematics", "mathematical"],
  ml: ["machine learning", "ml"],
  ai: ["artificial intelligence", "ai"],
  phd: ["phd", "ph.d", "doctorate"],
};

/**
 * A requirement is supported when its concrete terms are in the resume.
 * Qualifiers such as "proficiency" or "background" do not have to appear verbatim,
 * and "CS" counts as "computer science".
 */
export function requirementSupported(requirement: string, haystack: string): boolean {
  const hayText = haystack.toLowerCase();
  if (hayText.includes(requirement.toLowerCase())) return true;
  const hay = termSet(haystack);
  const tokens = tokenize(requirement)
    .flatMap((token) => token.split(/[/+]/))
    .map((token) => token.trim())
    .filter((token) => token.length > 1 && !QUALIFIER.has(token));
  if (tokens.length === 0) return false;
  return tokens.every((token) => {
    if (token === "programming" || token === "programmer") {
      return hayText.includes("computer science") || [...hay].some((term) => PROGRAMMING.has(term));
    }
    const options = ALIAS[token] ?? [token];
    return options.some((option) => (option.includes(" ") ? hayText.includes(option) : hay.has(option)));
  });
}

export function overlapScore(a: string, b: string): number {
  const sa = termSet(a);
  const sb = termSet(b);
  if (sa.size === 0 || sb.size === 0) return 0;
  let hits = 0;
  for (const t of sa) if (sb.has(t)) hits++;
  return hits / Math.min(sa.size, sb.size);
}

export function truncate(text: string, maxChars: number): string {
  if (text.length <= maxChars) return text;
  return `${text.slice(0, maxChars - 1)}…`;
}

export function collapseWhitespace(text: string): string {
  return text
    .replace(/\r/g, "")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}
