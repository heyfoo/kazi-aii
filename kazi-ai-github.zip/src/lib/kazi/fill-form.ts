import { appendFileSync, mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import type { Browser, Frame, FrameLocator, Page } from "playwright";
import type { Job, ResumeProfile } from "./types";

export type Board = "greenhouse" | "lever" | "workable" | "generic";

export type FillPayload = {
  fullName: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  location: string;
  linkedIn: string;
  coverLetter: string;
  resumePath?: string;
};

type FieldKey = Exclude<keyof FillPayload, "resumePath">;

const FIELDS: Array<{ key: FieldKey; label: RegExp }> = [
  { key: "firstName", label: /first name/i },
  { key: "lastName", label: /last name/i },
  { key: "fullName", label: /full name|^name$/i },
  { key: "email", label: /e-?mail/i },
  { key: "phone", label: /phone|mobile/i },
  { key: "location", label: /location|city/i },
  { key: "linkedIn", label: /linkedin/i },
  { key: "coverLetter", label: /cover letter|additional information|note to(?: the)? hiring manager|message to(?: the)? hiring manager/i },
];

export function detectBoard(url: string): Board {
  const host = new URL(url).hostname.toLowerCase();
  if (host.includes("greenhouse.io")) return "greenhouse";
  if (host.includes("lever.co")) return "lever";
  if (host.includes("workable.com")) return "workable";
  return "generic";
}

export function payloadFrom(profile: ResumeProfile | undefined, job: Job, resumePath?: string): FillPayload {
  const fullName = profile?.name?.trim() || "Applicant";
  const parts = fullName.split(/\s+/).filter(Boolean);
  const linkedIn = profile?.links?.find((link) => /linkedin\.com/i.test(link)) ?? "";
  return {
    fullName,
    firstName: parts[0] ?? fullName,
    lastName: parts.slice(1).join(" "),
    email: profile?.email ?? "",
    phone: profile?.phone ?? "",
    location: profile?.location ?? "",
    linkedIn,
    coverLetter: job.coverLetter ?? "",
    resumePath,
  };
}

export function resumeUploadName(fullName: string): string {
  const slug = fullName.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "applicant";
  return `${slug}-resume.pdf`;
}

/** Plain HTML for the approved resume. Enough for a one-page PDF, not a full markdown engine. */
export function resumeHtml(markdown: string): string {
  const escaped = markdown.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const blocks: string[] = [];
  let list: string[] = [];
  const flush = () => {
    if (list.length === 0) return;
    blocks.push(`<ul>${list.join("")}</ul>`);
    list = [];
  };
  const inline = (text: string) => text.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/\*(.+?)\*/g, "<em>$1</em>");
  for (const line of escaped.split("\n")) {
    if (line.startsWith("- ")) {
      list.push(`<li>${inline(line.slice(2))}</li>`);
      continue;
    }
    flush();
    if (line.startsWith("### ")) blocks.push(`<h3>${inline(line.slice(4))}</h3>`);
    else if (line.startsWith("## ")) blocks.push(`<h2>${inline(line.slice(3))}</h2>`);
    else if (line.startsWith("# ")) blocks.push(`<h1>${inline(line.slice(2))}</h1>`);
    else if (line.trim()) blocks.push(`<p>${inline(line)}</p>`);
  }
  flush();
  return `<!doctype html><html><head><meta charset="utf-8"><style>
    body{font-family:Georgia,serif;font-size:11pt;color:#111;margin:0.65in;}
    h1{font-size:18pt;margin:0 0 6px;}
    h2{font-size:12.5pt;border-bottom:1px solid #bbb;margin:16px 0 6px;}
    h3{font-size:11.5pt;margin:10px 0 2px;}
    p,li{margin:0 0 4px;line-height:1.35;}
    ul{margin:0 0 8px;padding-left:1.15em;}
  </style></head><body>${blocks.join("\n")}</body></html>`;
}

export function writeResumeFile(job: Job, dir: string): string | undefined {
  if (!job.tailoredResume) return undefined;
  mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${job.id}-resume.md`);
  writeFileSync(file, job.tailoredResume);
  return file;
}

/** A PDF the employer can open. Boards such as Greenhouse reject a .md upload. */
export async function writeResumePdf(markdown: string, dir: string, fullName: string): Promise<string> {
  mkdirSync(dir, { recursive: true });
  const file = path.join(dir, resumeUploadName(fullName));
  const { chromium } = await import("playwright");
  const browser = await chromium.launch({ headless: true });
  try {
    const page = await browser.newPage();
    await page.setContent(resumeHtml(markdown), { waitUntil: "load" });
    await page.pdf({ path: file, format: "Letter", printBackground: true });
  } finally {
    await browser.close();
  }
  return file;
}

type Scope = Page | Frame | FrameLocator;

async function applicationScope(page: Page): Promise<Scope> {
  const frame = page.locator('iframe[src*="greenhouse"], iframe[id*="grnhse"], iframe[title*="application" i]');
  if ((await frame.count()) > 0) {
    const inner = await frame.first().contentFrame();
    if (inner) return inner;
  }
  return page;
}

/** Opens the application form when the posting page only shows an Apply link. */
export async function maybeOpenApplication(page: Page): Promise<void> {
  const scope = await applicationScope(page);
  if ((await scope.getByLabel(/e-?mail/i).count()) > 0) return;
  const apply = scope
    .getByRole("link", { name: /apply for this job|^apply( now)?$/i })
    .or(scope.getByRole("button", { name: /apply for this job|^apply( now)?$/i }));
  if ((await apply.count()) > 0) {
    await apply.first().click();
    await scope.getByLabel(/e-?mail|first name|note to(?: the)? hiring manager/i).first().waitFor({ timeout: 15000 }).catch(() => undefined);
  }
}

async function fillLabel(scope: Scope, label: RegExp, value: string): Promise<boolean> {
  const box = scope.getByLabel(label);
  const count = await box.count();
  if (count === 0 || !value) return false;
  let filled = false;
  for (let i = 0; i < count; i++) {
    const control = box.nth(i);
    const kind = await control.evaluate((el) => (el instanceof HTMLInputElement ? el.type : el.tagName.toLowerCase()));
    if (kind === "file" || kind === "checkbox" || kind === "radio" || kind === "button" || kind === "submit") continue;
    await control.fill(value);
    filled = true;
  }
  return filled;
}

async function attachResume(scope: Scope, resumePath: string): Promise<boolean> {
  const files = scope.locator('input[type="file"]');
  const count = await files.count();
  const ext = path.extname(resumePath).toLowerCase();
  for (let i = 0; i < count; i++) {
    const input = files.nth(i);
    const accept = ((await input.getAttribute("accept")) ?? "").toLowerCase();
    const allowed = !accept || accept.split(",").some((part) => {
      const token = part.trim();
      return token.includes(ext) || token === ".*" || token.endsWith("/*");
    });
    if (!allowed) continue;
    const label = await input.evaluate((el) => [...((el as HTMLInputElement).labels ?? [])].map((item) => item.innerText).join(" "));
    if (count > 1 && /cover|letter|hiring manager/i.test(label)) continue;
    await input.setInputFiles(resumePath);
    return true;
  }
  return false;
}

/**
 * Types approved values into labeled fields. Never clicks Submit.
 * Returns the labels that were actually filled.
 */
export async function fillKnownFields(page: Page, payload: FillPayload): Promise<string[]> {
  await maybeOpenApplication(page);
  const scope = await applicationScope(page);
  const filled: string[] = [];

  for (const field of FIELDS) {
    const value = payload[field.key];
    if (!value) continue;
    if (await fillLabel(scope, field.label, value)) filled.push(field.key);
  }

  // Lever's comment box is the cover letter, and it is often unlabeled.
  if (payload.coverLetter && !filled.includes("coverLetter")) {
    const comments = scope.locator('textarea[name="comments"]');
    if ((await comments.count()) > 0) {
      await comments.first().fill(payload.coverLetter);
      filled.push("coverLetter");
    }
  }

  if (payload.resumePath && (await attachResume(scope, payload.resumePath))) filled.push("resumePath");

  return filled;
}

export async function readKnownFields(page: Page): Promise<Record<string, string>> {
  const scope = await applicationScope(page);
  const values: Record<string, string> = {};
  for (const field of FIELDS) {
    const box = scope.getByLabel(field.label);
    if ((await box.count()) === 0) continue;
    values[field.key] = await box.first().inputValue();
  }
  return values;
}

export function recordEdits(file: string, url: string, before: Record<string, string>, after: Record<string, string>) {
  const edits = Object.keys(before)
    .filter((key) => after[key] !== undefined && after[key] !== before[key])
    .map((key) => ({ field: key, from: before[key], to: after[key] }));
  if (edits.length === 0) return;
  mkdirSync(path.dirname(file), { recursive: true });
  appendFileSync(file, JSON.stringify({ url, edits, at: new Date().toISOString() }) + "\n");
}

const BANNER = (board: Board) => `
  const bar = document.createElement("div");
  bar.textContent = "Kazi filled the ${board} fields it recognized. Review them, then click Submit yourself. Kazi will not.";
  bar.setAttribute("style", "position:fixed;z-index:2147483647;left:0;right:0;bottom:0;padding:12px 16px;background:#111;color:#fff;font:14px/1.4 sans-serif");
  document.body.appendChild(bar);
`;

export async function runFillSession(options: {
  url: string;
  payload: FillPayload;
  headless?: boolean;
  editsFile?: string;
  /** When false, return as soon as the form is filled. The smoke test uses this. */
  waitForUser?: boolean;
}): Promise<{ board: Board; filled: string[] }> {
  const { chromium } = await import("playwright");
  const board = detectBoard(options.url);
  const browser: Browser = await chromium.launch({ headless: options.headless ?? false, slowMo: options.headless ? 0 : 40 });
  const page = await browser.newPage();
  await page.goto(options.url, { waitUntil: "domcontentloaded" });
  const filled = await fillKnownFields(page, options.payload);
  const before = await readKnownFields(page);

  if (options.waitForUser === false) {
    await browser.close();
    return { board, filled };
  }

  await page.evaluate(BANNER(board));
  let latest = before;
  const timer = setInterval(() => {
    readKnownFields(page).then((values) => {
      latest = values;
    }).catch(() => undefined);
  }, 1500);

  await new Promise<void>((resolve) => {
    const done = () => resolve();
    browser.on("disconnected", done);
    page.on("close", done);
  });
  clearInterval(timer);
  if (options.editsFile) recordEdits(options.editsFile, options.url, before, latest);
  await browser.close().catch(() => undefined);
  return { board, filled };
}
