import { findSkills } from "./lexicon";
import { termSet, tokenize } from "../text";

export const PROOF_MARK = "[NEEDS PROOF]";

const PROOF_RE = /\[\s*NEEDS PROOF\s*\]/gi;

/** Verbs and glue a tighter rewrite may use without becoming a new claim. */
const GLUE = new Set(
  "use used using via led lead built build made make ran run improved reduced measured trained designed implemented developed created applied including achieved produced showed shown showing results result within during across onto toward towards".split(
    /\s+/,
  ),
);

const PADDING =
  /(^|[^-\w])(robust|rigorous|rigorously|critical|critically|sophisticated|pioneered|pioneering)(?=$|[^-\w])/gi;

export function stripProofMark(text: string): string {
  return cleanup(text.replace(PROOF_RE, " "));
}

export function ensureProofMark(name: string): string {
  const bare = stripProofMark(name);
  return bare ? `${bare} ${PROOF_MARK}` : "";
}

/** Drop a padding word the model added. Keep it when the original line already used it. */
function stripAddedPadding(original: string, rewritten: string): string {
  const orig = original.toLowerCase();
  return cleanup(
    rewritten.replace(PADDING, (full, prefix: string, word: string) => (orig.includes(word.toLowerCase()) ? full : prefix)),
  );
}

function numberTokens(text: string): string[] {
  return (text.match(/\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?/g) ?? []).map((n) => n.replace(/,/g, ""));
}

function unsupportedAdditions(original: string, rewritten: string, extraGlue?: Set<string>, minLength = 4): boolean {
  const origNumbers = new Set(numberTokens(original));
  if (numberTokens(rewritten).some((n) => !origNumbers.has(n))) return true;

  const origSkills = new Set(findSkills(original).map((s) => s.toLowerCase()));
  if (findSkills(rewritten).some((s) => !origSkills.has(s.toLowerCase()))) return true;

  const origUpper = original.toUpperCase();
  const acronyms = rewritten.match(/\b[A-Z][A-Z0-9]{1,5}\b/g) ?? [];
  if (acronyms.some((a) => !origUpper.includes(a))) return true;

  const origTerms = termSet(original);
  return tokenize(rewritten).some((t) => t.length >= minLength && !origTerms.has(t) && !GLUE.has(t) && !extraGlue?.has(t));
}

/**
 * Backstop for a rewritten bullet or real project. Adds [NEEDS PROOF] when the
 * rewrite introduces a fact, number, domain, or outcome that is not literally
 * in the original line. Keeps a mark the model already added.
 */
export function guardRewrite(original: string, rewritten: string): string {
  const modelMarked = /\[\s*NEEDS PROOF\s*\]/i.test(rewritten);
  const cleaned = stripAddedPadding(original, stripProofMark(rewritten));
  if (!cleaned) return original;
  if (modelMarked || unsupportedAdditions(original, cleaned)) return `${cleaned} ${PROOF_MARK}`;
  return cleaned;
}

const LETTER_GLUE = new Set(
  "applying application position posting hiring welcome chance thank thanks consideration sincerely interest background experience relevant working writing research company focus lines closely looking forward strong please further discuss happy opportunity regarding currently recently candidate strengths evidence letter dear team would could should about doing living making worked works".split(
    /\s+/,
  ),
);

/**
 * Marks each cover-letter sentence that adds a fact, number, domain, or outcome
 * not literally in `source`. Greeting and sign-off lines are left alone.
 * `source` should be the resume plus the target company and role.
 */
export function guardCoverLetter(letter: string, source: string): string {
  return letter
    .split("\n")
    .map((line) => {
      if (!line.trim()) return line;
      return line
        .split(/(?<=[.!?])\s+/)
        .map((sentence) => guardCoverSentence(sentence, source))
        .join(" ");
    })
    .join("\n")
    .trim();
}

function guardCoverSentence(sentence: string, source: string): string {
  const trimmed = sentence.trim();
  if (/^(dear|sincerely)\b/i.test(trimmed)) return trimmed;
  const modelMarked = /\[\s*NEEDS PROOF\s*\]/i.test(trimmed);
  const cleaned = stripAddedPadding(source, stripProofMark(trimmed));
  if (!cleaned) return trimmed;
  const needs = modelMarked || unsupportedAdditions(source, cleaned, LETTER_GLUE, 5);
  const punctMatch = cleaned.match(/^(.*?)([.!?])$/);
  const body = (punctMatch?.[1] ?? cleaned).trim();
  const punct = punctMatch?.[2] ?? "";
  if (!needs) return punct ? `${body}${punct}` : body;
  return punct ? `${body} ${PROOF_MARK}${punct}` : `${body} ${PROOF_MARK}`;
}

/** Invented text is fictional, so padding comes off and the proof mark stays on the name only. */
export function leanInventedText(text: string): string {
  return stripAddedPadding("", stripProofMark(text));
}

/** A skill the profile does not already list is a new claim and must be marked. */
export function markUnownedSkill(skill: string, owned: string[]): string {
  const bare = stripProofMark(skill);
  if (!bare) return skill.trim();
  const known = owned.some((s) => s.toLowerCase() === bare.toLowerCase());
  return known ? bare : `${bare} ${PROOF_MARK}`;
}

function cleanup(text: string): string {
  return text
    .replace(/\s{2,}/g, " ")
    .replace(/\s+([,.;:])/g, "$1")
    .trim();
}
