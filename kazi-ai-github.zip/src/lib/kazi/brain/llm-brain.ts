import { z } from "zod";
import type { Generator } from "../llm/generator";
import { generate, generateJson, type Tracked } from "../llm/router";
import { truncate } from "../text";
import { JDAnalysis, ResumeProfile } from "../types";
import type { Brain, CoverLetterInput, TailorInput, TailorOutput, UnsupportedClaimsInput } from "./brain";
import { ensureProofMark, guardCoverLetter, guardRewrite, leanInventedText, markUnownedSkill, stripProofMark } from "./proof";
import { renderResumeMarkdown } from "./render";


// Prompts are written for 3B-class models: short, explicit field lists, one job per call.
export class LlmBrain implements Brain {
  name: string;
  cacheKey: string;

  constructor(
    private chain: Generator[],
    private tracker: Tracked,
  ) {
    this.name = chain.map((g) => `${g.name}:${g.model}`).join(" → ");
    this.cacheKey = `llm:${this.name}`;
  }

  async extractProfile(resumeText: string): Promise<ResumeProfile> {
    return generateJson(
      this.chain,
      ResumeProfile,
      {
        system: `You convert resumes into JSON. Use empty strings or empty arrays when something is missing.`,
        prompt: `Return JSON with keys: name, headline, email, phone, location, links (array), summary, skills (array of short strings), experience (array of {company, title, dates, bullets: array}), education (array of {school, degree, dates}), projects (array of {name, description}).\n\nRESUME:\n${truncate(resumeText, 9000)}`,
        maxTokens: 1800,
        temperature: 0,
      },
      this.tracker,
    );
  }

  async analyzeJob(jdText: string, url: string): Promise<JDAnalysis> {
    return generateJson(
      this.chain,
      JDAnalysis,
      {
        system: "You extract structured facts from job postings and build a hiring benchmark. Facts must come from the posting. exampleCandidate is a composite of real public career patterns for this kind of role, not a named person and not the applicant. Output JSON only.",
        prompt: `Return JSON with keys: title, company, location, seniority, mustHave (array of required skills/qualifications, max 10, each a short skill or credential, not a sentence), niceToHave (array, max 8), responsibilities (array, max 6, short), keywords (array of ATS keywords, max 15), summary (2 sentences), signals (array, max 6, what this role selects for), strongEvidence (array, max 6, what strong proof of each signal looks like), exampleCandidate (string, no person's name. Describe a composite of publicly documented backgrounds for this exact role: the degrees, labs, teams, and work that show up on real team pages and conference bios. Name the public pattern, such as a physics PhD plus a published trading internship. Do not invent a person.), rubric (array of {criterion, weight}, weights sum to 1).\n\nURL: ${url}\n\nJOB POSTING:\n${truncate(jdText, 7000)}`,
        maxTokens: 6000,
        temperature: 0,
      },
      this.tracker,
    );
  }

  async tailorResume(input: TailorInput): Promise<TailorOutput> {
    const { profile, analysis, bulletScores } = input;

    // Pick the bullets most worth rewriting so a small model only touches a handful.
    const candidates = profile.experience
      .flatMap((exp, ei) => exp.bullets.map((text, bi) => ({ key: `${ei}:${bi}`, text, score: bulletScores[`${ei}:${bi}`] ?? 1 })))
      .sort((a, b) => b.score - a.score)
      .slice(0, 8);

    const schema = z.object({
      
      skillOrder: z.array(z.string()),
      rewrittenBullets: z.record(z.string(), z.string()),
      rewrittenProjects: z.record(z.string(), z.string()).default({}),
      inventedProjects: z
        .array(
          z.object({
            name: z.string(),
            description: z.string().default(""),
            gap: z.string().default(""),
          }),
        )
        .default([]),
      changeNotes: z.array(z.string()),
    });

    const out = await generateJson(
      this.chain,
      schema,
      {
        system: `You tailor resumes to a specific job posting. Write terse, number-first, adjective-free technical lines. Lead with the tool, method, or result already in the source, then the number when the original has one. Do not add adjectives. Do not use padding words such as robust, rigorous, critical, sophisticated, or pioneered.

Unsupported means any fact, number, domain, or outcome that does not literally appear in the original line. End that rewritten line with [NEEDS PROOF].

You may invent new projects that close a benchmark gap. End each invented project's name with [NEEDS PROOF]. Never put an invented fact inside a real bullet or real project and leave it unmarked.`,
        prompt: `TARGET ROLE: ${analysis.title} at ${analysis.company}
MUST-HAVE: ${analysis.mustHave.join("; ")}
KEYWORDS: ${analysis.keywords.join(", ")}
SELECTION SIGNALS: ${analysis.signals.join("; ")}
STRONG EVIDENCE: ${analysis.strongEvidence.join("; ")}
RUBRIC: ${JSON.stringify(analysis.rubric)}
EXAMPLE CANDIDATE (fictional benchmark): ${analysis.exampleCandidate}


CANDIDATE SKILLS: ${profile.skills.join(", ")}
CANDIDATE HEADLINE: ${profile.headline}

BULLETS TO REWRITE (keep the original facts; lead with the number when the original has one. Unsupported means any fact, number, domain, or outcome that does not literally appear in the original line. If a rewrite adds one, end that line with [NEEDS PROOF]):
${candidates.map((c) => `[${c.key}] ${c.text}`).join("\n")}
PROJECTS TO REWRITE (same unsupported rule as bullets; terse and number-first: what you built, how, and the measurable result already in the original. Rewrite every real project. Never drop one):
${profile.projects.map((p, i) => `[${i}] ${p.name}: ${p.description}`).join("\n")}
INVENT NEW PROJECTS only for a benchmark gap no real project shows (signals, strong evidence, rubric, example candidate). Each one is fictional. End its name with [NEEDS PROOF]. Put the gap in "gap", not in changeNotes.
Return JSON: {
  "skillOrder": [the candidate's existing skills reordered by relevance to this role, plus benchmark skills they lack, each new one ending with [NEEDS PROOF]],
  "rewrittenBullets": {"<key>": "<rewritten bullet>", ...} for the bullets above,
  "rewrittenProjects": {"<index>": "<rewritten description>", ...} for every real project above,
  "inventedProjects": [{"name": "<name> [NEEDS PROOF]", "description": "<terse technical description>", "gap": "<signal, evidence item, or rubric criterion this fills>"}],
  "changeNotes": ["short note explaining each notable change to a real line or skill"]
}`,
        maxTokens: 4000,
        temperature: 0.3,
      },
      this.tracker,
    );

    const skillOrder = out.skillOrder.map((s) => markUnownedSkill(s, profile.skills));
    for (const s of profile.skills) {
      if (!skillOrder.some((k) => stripProofMark(k).toLowerCase() === s.toLowerCase())) skillOrder.push(s);
    }

    const rewrittenBullets: Record<string, string> = {};
    for (const [key, value] of Object.entries(out.rewrittenBullets)) {
      const original = candidates.find((c) => c.key === key)?.text;
      rewrittenBullets[key] = original ? guardRewrite(original, value) : value;
    }

    const rewrittenProjects: Record<string, string> = {};
    for (const [key, value] of Object.entries(out.rewrittenProjects)) {
      const project = profile.projects[Number(key)];
      if (!project) continue;
      rewrittenProjects[key] = guardRewrite(project.description, value);
    }

    const realNames = new Set(profile.projects.map((p) => stripProofMark(p.name).toLowerCase()));
    const inventedProjects = out.inventedProjects
      .map((p) => ({
        name: ensureProofMark(p.name),
        description: leanInventedText(p.description),
        gap: p.gap.trim(),
      }))
      .filter((p) => p.name && !realNames.has(stripProofMark(p.name).toLowerCase()));

    const bulletOrder: Record<number, number[]> = {};
    profile.experience.forEach((exp, ei) => {
      bulletOrder[ei] = exp.bullets
        .map((_, bi) => bi)
        .sort((a, b) => (bulletScores[`${ei}:${b}`] ?? 1) - (bulletScores[`${ei}:${a}`] ?? 1));
    });

    const changeNotes = [
      ...out.changeNotes.filter((note) => !inventedProjects.some((p) => note.toLowerCase().includes(stripProofMark(p.name).toLowerCase()))),
      ...inventedProjects.map((p) => `Invented "${p.name}" to fill: ${p.gap || "a gap against the benchmark"}.`),
    ];

    return {
      resumeMarkdown: renderResumeMarkdown(profile, {
        skillOrder,
        bulletOrder,
        rewrittenBullets,
        rewrittenProjects,
        inventedProjects,
      }),
      changeNotes,
    };
  }

  async writeCoverLetter(input: CoverLetterInput): Promise<string> {
    const { profile, analysis, matchedSkills, evidence } = input;
    const source = [
      profile.name,
      profile.headline,
      profile.summary,
      profile.skills.join(" "),
      ...profile.experience.flatMap((e) => [e.company, e.title, e.dates, ...e.bullets]),
      ...profile.education.flatMap((e) => [e.school, e.degree, e.dates]),
      ...profile.projects.flatMap((p) => [p.name, p.description]),
      analysis.company,
      analysis.title,
      analysis.location,
    ]
      .filter(Boolean)
      .join("\n");
    const res = await generate(
      this.chain,
      {
        system: `You write concise, specific cover letters (220-320 words, 3-4 short paragraphs). Attribute each achievement to the context it happened even if hypothetical(be specific and realistic ; hackathons, projects, etc). No clichés like "I am writing to express my interest". Show  real research, a unique story or perspective, and concrete proof of ability (portfolios, demos, results)—instead of polished but generic AI-generated text that all sounds the same. Produce the shortest possible message that a smart human who actually did the research and has real results would write—never the longest, most polished message an LLM can generate. Plain text, no markdown headers.`,
        prompt: `Candidate: ${profile.name}, ${profile.headline}
Role: ${analysis.title} at ${analysis.company}
Why the role matters (from posting): ${analysis.summary}
Must-haves: ${analysis.mustHave.join("; ")}
Candidate's matching strengths: ${matchedSkills.join(", ") || "(see evidence)"}
BENCHMARK (use this for hypothetical achievements; it is fictional):
Selection signals: ${analysis.signals.join("; ")}
Strong evidence: ${analysis.strongEvidence.join("; ")}
Rubric: ${JSON.stringify(analysis.rubric)}
Example candidate: ${analysis.exampleCandidate}
Evidence from the resume to draw on:
${evidence.map((e) => `- ${e}`).join("\n")}

Write the letter. Start with "Dear Hiring Team," and end with "Sincerely,\n${profile.name}".`,
        maxTokens: 700,
        temperature: 0.5,
      },
      this.tracker,
    );
    return guardCoverLetter(res.text.trim(), source);
  }

  async listUnsupportedClaims(input: UnsupportedClaimsInput): Promise<string[]> {
    const out = await generateJson(
      this.chain,
      z.object({ claims: z.array(z.string()) }),
      {
        system: "You audit cover letters against resumes. Output JSON only.",
        prompt: `List every concrete claim in the COVER LETTER (skills, tools, employers, titles, numbers, achievements) that is NOT supported by the RESUME. Return {"claims": ["..."]}. Return an empty array if everything is supported.\n\nRESUME:\n${truncate(input.resumeText, 6000)}\n\nCOVER LETTER:\n${input.coverLetter}`,
        maxTokens: 400,
        temperature: 0,
      },
      this.tracker,
    );
    return out.claims;
  }
}
